import pygame
from pygame.mixer import fadeout
import Sprites
from Reference import Ref,WIDTH,HEIGHT


ref = Ref((WIDTH,HEIGHT))


class Consol():
    def __init__(self):
        self.turn = 0
        self.INPUT_TO_INDEX = {"up":0, "down":1, "right":2, "left":3}
        self.PIECELISTE = ("eponge", "patate", "dejavu", "billy")
        self.ACTION = {"move": self.MovePiece, "exit":exit}
        self.ACTIONLISTE = ("move","exit")
        self.DIR = ("up","down","right","left")
        self.COLOR = ("white", "black")
        self.OBJECTCOMANDS = {"epongewhite":[Sprites.epongeBlanche.Up,Sprites.epongeBlanche.Down,Sprites.epongeBlanche.Left,Sprites.epongeBlanche.Right], 
                        "epongeblack":[Sprites.epongeNoire.Up,Sprites.epongeNoire.Down,Sprites.epongeNoire.Left,Sprites.epongeNoire.Right],
                        "patatewhite":[Sprites.patateBlanche.Up,Sprites.patateBlanche.Down,Sprites.patateBlanche.Left,Sprites.patateBlanche.Right], 
                        "patatblack":[Sprites.patateNoire.Up,Sprites.patateNoire.Down,Sprites.patateNoire.Left,Sprites.patateNoire.Right], 
                        "billywhite":[Sprites.billyBlanc.Up,Sprites.billyBlanc.Down,Sprites.billyBlanc.Left,Sprites.billyBlanc.Right],
                        "billyblack":[Sprites.billyNoire.Up,Sprites.billyNoire.Down,Sprites.billyNoire.Left,Sprites.billyNoire.Right],
                        "dejavuwhite":[Sprites.dejaVuBlanc.UpLeft,Sprites.dejaVuBlanc.UpRight,Sprites.dejaVuBlanc.DownLeft,Sprites.dejaVuBlanc.DownRight],
                        "dejavublack":[Sprites.dejaVuNoire.UpLeft,Sprites.dejaVuNoire.UpRight,Sprites.dejaVuNoire.DownLeft,Sprites.dejaVuNoire.DownRight] }
        
    def NewRound(self):
        print(f"Nouveau tour, au {self.COLOR[self.turn]} de jouer")
        turn = None
        while turn is None:
            turn = str(input(f"Que voulez-vous faire ? : {self.ACTIONLISTE}: ")).lower()
            if turn in self.ACTION.keys():
                self.ACTION[turn]()
            else: 
                print("La fonction n'est pas reconnue")
    
    def SetTurn(self):
        self.turn = 1 if self.turn == 0 else 0
    
    def MovePiece(self):
        piece = self.DefPiece()
        color = self.COLOR[self.turn]
        dir = self.DefDir()
        dist = None
        if piece in ("patate", "dejavu"):
            dist = self.DefDist()
        self.OBJECTCOMANDS[piece+color][dir](dist)
        self.SetTurn()
        
        
    def DefDir(self):
        _dir = None
        while _dir is None:
            _dir = str(input(f"Quelle direction ? : {self.DIR}: ")).lower()
            if _dir in self.DIR:
                return self.INPUT_TO_INDEX[_dir]
            else:
                print(f"La direction {_dir} n'existe pas")
                _dir = None
        
    
    def DefDist(self):
        _dist = None
        while _dist is None:
            _dist = int(input("Quelle distance ? : "))
            if type(_dist) is int:
                return _dist
            else:
                _dist = None
    

    def DefPiece(self):
        _piece = None
        while _piece == None:
            _piece = str(input(f"Quelle piece voulez-vous jouer ? :{self.PIECELISTE}: ")).lower()
            if _piece in self.PIECELISTE:
                return _piece
            else:
                return None
            
run = True
consol = Consol()
while run:


    print(Sprites.map)
    consol.NewRound()