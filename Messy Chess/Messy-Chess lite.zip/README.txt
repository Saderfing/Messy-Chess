Cette version est la moins buggé possible une autre version existe 
à ce lien mais avec beaucoup de bug: https://github.com/Saderfing/Messy-Chess